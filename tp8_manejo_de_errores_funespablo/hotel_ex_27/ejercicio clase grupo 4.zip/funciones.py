def caso_1(lista):
    while True:
        try:
            cantidad = int(input("¿Cuantas habitaciones desea ingresar?: ").strip())
            if cantidad > 0:
                break
            else:
                print("No existen las habitaciones negativas...")
        except ValueError:
            print("Por favor ingrese un número!")
    for _ in range(cantidad):
        while True:
            try:
                no_existe=False
                numero = int(input("Por favor, ingrese el número de habitación: ").strip())
                for habitacion in lista:
                    if habitacion["numero"] == numero:
                        print("Error, la habitación ingresada ya existe. ")
                    else:
                        no_existe=True
                if no_existe:
                    nueva_habitacion={"Numero":numero, "Estado":0}
                    lista.append(nueva_habitacion)
                    print("Habitación ingresada correctamente!!")
            except ValueError:
                print("Por favor ingrese un número!")

def caso_2(lista):
   for habitacion in lista:
            while True:
                try:
                    estado_actual = "Ocupada" if habitacion["estado"] == 1 else "Libre"
                    estado_nuevo = int(input(
                        f"Ingrese el estado de habitación {habitacion["numero"]} ({estado_actual}) "
                        "(1 = ocupada, 0 = libre): "
                    ))
                    if estado_nuevo in [0, 1]:
                        habitacion["estado"] = estado_nuevo
                        print(f"Habitación {habitacion["numero"]} está "
                            f"{'Ocupada' if estado_nuevo == 1 else 'Libre'}! ")
                        break
                    else:
                        print("Eror, ingrese solo 0 o 1. ")
                except ValueError:
                    print("Error, ingrese un número válido. ")
def caso_3(lista):
  while True:
    try:
      numero = int(input("Ingrese el número de la habitación: ").strip())
      hab_encontrada = False
      for habitacion in lista:
        if habitacion["numero"] == numero:
          print(f"El estado de la habitación {numero} es: {"Ocupada" if habitacion["estado"] == 1 else "Libre"}")
          hab_encontrada = True
          break
      if not hab_encontrada:
        print("ERROR. No existe ese número de habitación.")
        continue
      else:
        break
    except ValueError:
      print("ERROR. Ingrese un número válido.")
    
def caso_4(lista):
  estado_habitacion = None 
  while True:
    try:
      hab_encontrada = False
      numero = int(input("Ingrese el número de la habitación: ").strip())
      for habitacion in lista:
        if habitacion["numero"] == numero:
          print(f"El estado de la habitación {numero} es: {'Ocupada' if habitacion['estado'] == 1 else 'Libre'}")
          hab_encontrada = True
          estado_habitacion = habitacion["estado"]
          break
      if not hab_encontrada:
        print("ERROR. No existe ese número de habitación.")
        continue
      else:
        break
    except ValueError:
      print("ERROR. Ingrese un número válido.")

  while True:
    try:
      hab_encontrada = False
      estado_nuevo = int(input(f"Ingrese el nuevo estado de la habitación {numero} ({"Ocupada" if estado_habitacion == "1" else "Libre"}) (Ingrese 1 para ocupada y 0 para libre): ").strip())
      if estado_nuevo in [0, 1]:
        for habitacion in lista:
          if habitacion["numero"] == numero:
            habitacion["estado"] = estado_nuevo
            print(f"La habitación {numero} fue reasignada a {"Ocupada" if estado_nuevo == 1 else "Libre"}")
            hab_encontrada = True
            break
          continue
        if hab_encontrada:
          break
      else:
        print("ERROR. Ingrese un estado válido (0 o 1).")
    except ValueError:
      print("ERROR. Ingrese un número válido para el estado.")

def caso_5(lista):
    while True:
        try:
            opcion = int(input('Ingrese si quiere listar habitaciones libres(1) u ocupadas(2): ').strip())
        except ValueError:
            print('Ingrese un número correcto')
        else:
            match opcion:
                case 1:
                    for habitacion in lista:
                        if habitacion['estado'] == 0:
                            print(f'Habitación {habitacion['numero']} libre')
                    break
                case 2:
                    for habitacion in lista:
                        if habitacion['estado'] == 1:
                            print(f'Habitación {habitacion['numero']} Ocupada')
                    break
                case _:
                    print('Ingrese una opcion dentro del rango (1 o 2)')