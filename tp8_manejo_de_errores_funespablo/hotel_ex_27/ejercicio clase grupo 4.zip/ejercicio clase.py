from funciones import *
habitaciones = [
  {
    "numero": 101,
    "estado": 0
  },
  {
    "numero": 102,
    "estado": 1
  },
  {
    "numero": 103,
    "estado": 0
  },
  {
    "numero": 104,
    "estado": 1
  }
]
while True:
  print(''' ---- Menú de gestión del Hotel ---- 
1- Agregar habitación  
2- Mostrar todas las habitaciones  
3- Consultar una habitación  
4- Cambiar estado de una habitación  
5- Listar habitaciones libres u ocupadas  
6- Salir''')
  opcion = input("Seleccione una opción: ")
  match opcion:
      case "1":
        caso_1(habitaciones)  
      case "2":
        caso_2(habitaciones)
      case "3":
        caso_3(habitaciones)
      case "4":
        caso_4(habitaciones)
      case "5":
        caso_5(habitaciones)
      case "6":
        print("Gracias por usar el sistema!!")
        break
      case _:
        print("ERROR... Comando no válido")